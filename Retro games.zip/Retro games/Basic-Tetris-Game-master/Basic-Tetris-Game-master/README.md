# Basic-Tetris-Game
This is a basic non-sense tetris game. In this basic HTML and CSS is used with some inbuilt javaScript methods.

Some JavaScript inbuilt methods used are:-
  addEventListener()
  querySelector()
  querySelectorAll()
  keyCode()
  Math.floor()
  Math.random()
  length
  forEach()
  splice()
  clearInterval()
  setInterval()
  some()
  innerHTML()
  every()
  add()
  remove()
  contains()
