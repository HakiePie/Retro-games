# mario-game
Mario game using only html, css and javascript
